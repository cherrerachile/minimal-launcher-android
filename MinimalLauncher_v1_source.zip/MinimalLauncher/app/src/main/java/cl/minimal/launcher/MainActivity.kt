package cl.minimal.launcher

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var greeting: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weather: TextView
    private var startY = 0f
    private val bg = Color.rgb(17, 20, 24)
    private val muted = Color.rgb(170, 180, 190)
    private val locale = Locale("es", "CL")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        home()
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 100)
        else refreshWeather()
        handler.post(object : Runnable { override fun run() { updateTime(); handler.postDelayed(this, 30_000) } })
    }
    private fun text(value: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); setPadding(0, 12, 0, 12)
    }
    private fun home() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 44, 32, 30); setBackgroundColor(bg) }
        setContentView(root)
        greeting = text("", 28f); root.addView(greeting)
        clock = text("", 58f); root.addView(clock)
        date = text("", 16f, muted); root.addView(date)
        weather = text("Clima: activa la ubicación", 17f, muted); root.addView(weather)
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        val installed = apps().take(6)
        installed.chunked(3).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { info ->
                val b = Button(this).apply { text = info.first; isAllCaps = false; textSize = 12f; setOnClickListener { launch(info.second) } }
                row.addView(b, LinearLayout.LayoutParams(0, 90, 1f))
            }
            root.addView(row)
        }
        val search = Button(this).apply { text = "Buscar aplicaciones  ↑"; isAllCaps = false; setOnClickListener { drawer() } }
        root.addView(search)
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startY = event.y; true }
                MotionEvent.ACTION_UP -> { if (startY - event.y > 110) drawer(); true }
                else -> true
            }
        }
        updateTime()
    }
    private fun updateTime() {
        if (!::clock.isInitialized) return
        val now = LocalDateTime.now()
        greeting.text = when(now.hour) { in 5..11 -> "Buen día, Cristian."; in 12..19 -> "Buenas tardes, Cristian."; else -> "Buenas noches, Cristian." }
        clock.text = now.format(DateTimeFormatter.ofPattern("HH:mm"))
        date.text = now.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", locale)).replaceFirstChar { it.uppercase(locale) }
    }
    private fun apps(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION") val results = packageManager.queryIntentActivities(intent, 0)
        return results.map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.filter { it.second != packageName }.sortedBy { it.first.lowercase(locale) }
    }
    private fun launch(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent) else Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show()
    }
    private fun drawer() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 10); setBackgroundColor(bg) }
        val input = EditText(this).apply { hint = "Buscar aplicación"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted) }
        panel.addView(input)
        val scroll = ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list); panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val all = apps()
        fun render(q: String) { list.removeAllViews(); all.filter { it.first.contains(q, true) }.forEach { app ->
            list.addView(text(app.first, 19f).apply { setOnClickListener { launch(app.second) } })
        } }
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s.toString()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        render(""); setContentView(panel)
        panel.addView(Button(this).apply { text = "Volver al inicio"; setOnClickListener { home() } })
    }
    override fun onBackPressed() { home() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) refreshWeather()
    }
    private fun refreshWeather() {
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            @Suppress("MissingPermission") val location = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (location == null) { weather.text = "Clima: esperando ubicación"; return }
            thread {
                try {
                    val url = "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,weather_code&timezone=auto"
                    val connection = URL(url).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                    val json = JSONObject(connection.getInputStream().bufferedReader().use { it.readText() }).getJSONObject("current")
                    val degrees = json.getDouble("temperature_2m").toInt()
                    val code = json.getInt("weather_code")
                    val condition = when(code) { 0 -> "Despejado"; 1,2,3 -> "Nubosidad"; 45,48 -> "Niebla"; in 51..67 -> "Lluvia"; in 71..77 -> "Nieve"; in 80..82 -> "Chubascos"; in 95..99 -> "Tormenta"; else -> "Variable" }
                    runOnUiThread { if (::weather.isInitialized) weather.text = "$degrees°C · $condition" }
                } catch (_: Exception) { runOnUiThread { if (::weather.isInitialized) weather.text = "Clima no disponible" } }
            }
        } catch (_: SecurityException) { weather.text = "Permite ubicación para mostrar el clima" }
    }
}
