# Minimal Launcher — Android

Proyecto inicial nativo Kotlin para Android Studio.

## Funciones
- Launcher HOME seleccionable en Ajustes de Android.
- Modo oscuro, saludo dinámico «Cristian», reloj y fecha.
- Seis accesos a aplicaciones instaladas (primeras seis por orden alfabético).
- Cajón de aplicaciones con búsqueda; gesto de deslizar hacia arriba.
- Clima actual mediante Open-Meteo y última ubicación disponible (requiere permiso).

## Compilar
1. Abre esta carpeta con Android Studio.
2. Instala Android SDK 35 y JDK 17 si se solicitan.
3. Sincroniza Gradle (requiere internet).
4. Ejecuta en el teléfono o selecciona Build > Build APK(s).
5. En Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio, selecciona Minimal Launcher.

## Limitaciones de esta versión
- Los seis accesos no son configurables todavía.
- El clima usa la última ubicación disponible y no se actualiza periódicamente.
- La búsqueda muestra las aplicaciones lanzables, sin iconos personalizados.
- No incluye APK precompilado. El proyecto no ha sido compilado ni probado en un dispositivo.
